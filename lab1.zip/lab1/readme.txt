Under this root directory, execute:
make

Then a file named 'twopass' will be generated.

Then execute './twopass <input filename>' will get the result.